function dragElement(elmnt, handle) {
  let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  handle.onmousedown = function(e) {
    e.preventDefault();
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    document.onmousemove = elementDrag;
  };
  function elementDrag(e) {
    e.preventDefault();
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
    if (elmnt.id === "txmd5-avatar") {
      const percent = document.getElementById("txmd5-percent");
      percent.style.top = elmnt.style.top;
      percent.style.left = elmnt.style.left;
    }
  }
  function closeDragElement() {
    document.onmouseup = null;
    document.onmousemove = null;
  }
}

function showPopup() {
  popup.style.display = "block";
  avatar.style.display = "none";
  percent.style.display = "none";
}

function hidePopup() {
  popup.style.display = "none";
  avatar.style.display = "block";
  avatar.style.top = popup.style.top;
  avatar.style.left = popup.style.left;
  percent.style.display = "block";
  percent.style.top = popup.style.top;
  percent.style.left = popup.style.left;
}


 



function handlePredict() {
  const md5Input = document.getElementById("md5Input");
  

  const md5 = document.getElementById("md5Input").value.trim().toLowerCase();
  if (!/^[a-f0-9]{32}$/.test(md5)) return alert("Mã MD5 không hợp lệ!");
  const resultText = "0123456789abcdef".indexOf(md5[md5.length - 1]) % 2 === 0 ? "XỈU" : "TÀI";
  const percentEl = document.getElementById("txmd5-percent");
  const resultEl = document.getElementById("popup-result");
  resultEl.innerText = "ĐANG DỰ ĐOÁN..."; percentEl.innerText = "";

  setTimeout(() => {
    if (popup.style.display === "none") {
      percentEl.innerText = resultText === "TÀI" ? "🟢  TÀI" : "🟢  XỈU"; percentEl.style.display = "block";
    } else {
      resultEl.innerText = "Kết quả: " + resultText;
    }
  }, 3000);
}


(function () {
  document.addEventListener("DOMContentLoaded", () => {
  percent.innerText = "🟢  TÀI -  XỈU";
  percent.style.display = "block";
  percent.style.top = avatar.style.top || "100px";
  percent.style.left = avatar.style.left || "100px";

  const userInfo = document.getElementById("popup-userinfo").innerText;
  if (!userInfo.trim() || userInfo.trim() === "") {
    document.getElementById("md5Input").style.display = "none";
    document.getElementById("popup-predict").style.display = "none";
    
  }
});
    const userInfo = document.getElementById("popup-userinfo").innerText;
    
if (!userInfo.trim() || userInfo.trim() === "") {
      document.getElementById("md5Input").style.display = "none";
      document.getElementById("popup-predict").style.display = "none";
    

      document.getElementById("md5Input").style.display = "none";
      document.getElementById("popup-predict").style.display = "none";
    }
  });

 const wrapper = document.createElement("div");
wrapper.innerHTML = `<div id="txmd5-popup" style="position:fixed; top:100px; left:100px; background:linear-gradient(135deg,#1c1f26,#2e3b4e); color:#ffffff; border-radius:20px; padding:20px; z-index:9999; box-shadow:0 10px 30px rgba(0,0,0,0.5); min-width:300px; font-family:'Segoe UI',sans-serif; resize:both; overflow:auto;">
  <div id="txmd5-header" style="cursor:move; font-weight:bold; font-size:20px; margin-bottom:12px; text-align:center;">🎲 TOOL TX MD5</div>
  <div id="txmd5-body">
    <div id="popup-result" style="margin-top:12px; font-weight:bold; text-align:center;">Kết quả sẽ hiển thị ở đây...</div><div id="txmd5-history" style="margin-top:10px; text-align:center; font-size:14px; color:#aaa;">Lịch sử: [ ]</div>
  </div>
  <div id="txmd5-contact" style="margin-top:20px; font-size:14px; text-align:center; color:#ccc;">
    <div style="margin-bottom:5px;">© 2025  HẢI CON</div>
    <div style="display:flex; justify-content:center; gap:10px;">
      <a href="https://zalo.me/0852337392" target="_blank" title="Zalo" style="color:#00ffcc;"><img src="https://img.icons8.com/ios-filled/24/00ffcc/zalo.png"/>Hải Con</a>
      <a href="https://facebook.com/nuyenduchaih2007" target="_blank" title="Facebook" style="color:#00ffcc;"><img src="https://img.icons8.com/ios-filled/24/00ffcc/facebook--v1.png"/>Hải Con</a>
      <a href="https://t.me/2haicon2007" target="_blank" title="Telegram" style="color:#00ffcc;"><img src="https://img.icons8.com/ios-filled/24/00ffcc/telegram-app.png"/>Hải Con</a>
    </div>
  </div>
  <div id="txmd5-close" style="position:absolute; top:6px; right:10px; cursor:pointer;">ĐÓNG</div>
</div>
<img id="txmd5-avatar" src="https://i.imgur.com/HauCFNi.png" style="display:none; position:fixed; width:432px; height:432px; border-radius:50%; cursor:move; z-index:9998;">
<div id="txmd5-percent" style="display:none; position:fixed; z-index:9999; color:#00ffcc; font-size:36px; font-weight:bold; text-shadow:0 0 10px #00ffcc;"></div>
`;

  document.body.appendChild(wrapper);

  window.popup = document.getElementById("txmd5-popup");
  window.avatar = document.getElementById("txmd5-avatar");
  window.percent = document.getElementById("txmd5-percent");

  // dragElement(popup);  // removed to prevent conflict
  dragElement(avatar, avatar);

  dragElement(popup, document.getElementById("txmd5-header"));
  document.getElementById("txmd5-close").onclick = hidePopup;
  avatar.onclick = showPopup;
  
 

// Yêu cầu quyền clipboard và theo dõi MD5 mới được copy
navigator.permissions.query({ name: "clipboard-read" }).then(result => {
  if (result.state === "granted" || result.state === "prompt") {
    navigator.clipboard.readText().then(text => {
      console.log("Quyền clipboard OK. MD5 đầu:", text);
    });
  } else {
    alert("Bạn cần cấp quyền clipboard để tiện ích hoạt động.");
  }
});

let lastClipboard = "";
setInterval(() => {
  navigator.clipboard.readText().then(text => {
    const md5 = text.trim().toLowerCase();
    if (/^[a-f0-9]{32}$/.test(md5) && md5 !== lastClipboard) {
      lastClipboard = md5;
      const resultText = "0123456789abcdef".indexOf(md5[md5.length - 1]) % 2 === 0 ? "XỈU" : "TÀI";
      const percentEl = document.getElementById("txmd5-percent");
      const resultEl = document.getElementById("popup-result");
      resultEl.innerText = "ĐANG DỰ ĐOÁN..."; percentEl.innerText = "";
      setTimeout(() => {
        if (popup.style.display === "none") {
          percentEl.innerText = resultText === "TÀI" ? "🟢  TÀI" : "🔴  XỈU";
          percentEl.style.color = resultText === "TÀI" ? "#00ffcc" : "#ff4444";
          percentEl.style.display = "block";

        } else {
          resultEl.innerText = "Kết quả: " + resultText;
        }
      }, 3000);
    }
  }).catch(err => console.error("Không thể đọc clipboard:", err));
}, 2000);


let isInverted = false;
let history = [];

function handlePredict(md5) {
  const resultEl = document.getElementById("popup-result");
  const percentEl = document.getElementById("txmd5-percent");

  if (!/^[a-f0-9]{32}$/.test(md5)) {
    resultEl.innerText = "Mã MD5 không hợp lệ!";
    resultEl.style.color = "#fff";
    return;
  }

  let output = "0123456789abcdef".indexOf(md5[md5.length - 1]) % 2 === 0 ? "XỈU" : "TÀI";
  if (isInverted) output = output === "TÀI" ? "XỈU" : "TÀI";

  resultEl.innerHTML = output === "TÀI"
    ? "🟢 Dự đoán theo thuật toán: <b style='color:#00ffcc'>TÀI</b>"
    : "🔴 Dự đoán theo thuật toán: <b style='color:#ff4444'>XỈU</b>";

  percentEl.innerText = output === "TÀI" ? "🟢  TÀI" : "🔴  XỈU";
  percentEl.style.color = output === "TÀI" ? "#00ffcc" : "#ff4444";
  percentEl.style.display = "block";

  history.unshift(output);
  if (history.length > 5) history.pop();

  const historyEl = document.getElementById("txmd5-history");
  if (historyEl) {
    historyEl.innerText = "Lịch sử: [ " + history.join(", ") + " ]";
  }
}
