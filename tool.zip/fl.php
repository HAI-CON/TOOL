<?php
// Gộp lại từ đoạn mã bạn gửi với chỉnh sửa đầy đủ logic:

date_default_timezone_set("Asia/Ho_Chi_Minh");

$cookie_file = __DIR__ . '/cookie.txt';

function input($text) {
    echo $text;
    return trim(fgets(STDIN));
}

function follow($fb_token, $idpost) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/' . $idpost . '/subscribers');
    
    $headers = [
        "Connection: keep-alive",
        "Keep-Alive: 300",
        "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7",
        "Accept-Language: vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cache-Control: max-age=0",
        "Upgrade-Insecure-Requests: 1",
        "Accept: application/json",
        "Expect:"
    ];
    
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    
    $postData = ['access_token' => $fb_token];
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
}


function curl_post($url, $data, $headers = []) {
    global $cookie_file;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => is_array($data) ? http_build_query($data) : $data,
        CURLOPT_COOKIEJAR => $cookie_file,
        CURLOPT_COOKIEFILE => $cookie_file,
        CURLOPT_HTTPHEADER => $headers,
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    return $res;
}

function curl_get($url, $headers = []) {
    global $cookie_file;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_COOKIEJAR => $cookie_file,
        CURLOPT_COOKIEFILE => $cookie_file,
        CURLOPT_HTTPHEADER => $headers,
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    return $res;
}

// === NHẬP TOKEN TTC ===
$ttc_token_file = __DIR__ . '/ttc_token.txt';
if (file_exists($ttc_token_file)) {
    $old = trim(file_get_contents($ttc_token_file));
    $use_old = strtolower(input("❓ Dùng lại token TTC cũ? (y/n): "));
    if ($use_old === 'y') {
        $ttc_token = $old;
    } else {
        $ttc_token = input("🔐 Nhập token Tương Tác Chéo: ");
        file_put_contents($ttc_token_file, $ttc_token);
    }
} else {
    $ttc_token = input("🔐 Nhập token Tương Tác Chéo: ");
    file_put_contents($ttc_token_file, $ttc_token);
}
// === NHẬP DANH SÁCH TOKEN FACEBOOK ===
$fb_token_file = __DIR__ . '/fb_tokens.txt';
$fb_tokens = [];

if (file_exists($fb_token_file)) {
    $use_old_fb = strtolower(input("❓ Dùng lại danh sách Facebook token cũ? (y/n): "));
    if ($use_old_fb === 'y') {
        $fb_tokens = array_filter(array_map('trim', file($fb_token_file)));
    }
}

if (empty($fb_tokens)) {
    echo "📥 Nhập nhiều token Facebook, mỗi dòng 1 token. Nhấn Enter dòng trống để kết thúc:\n";
    while (true) {
        $line = trim(fgets(STDIN));
        if ($line === '') break; // nếu dòng trống thì kết thúc
        $fb_tokens[] = $line;
    }
    file_put_contents($fb_token_file, implode("\n", $fb_tokens));
}

if (count($fb_tokens) === 0) die("❌ Không có token Facebook nào!\n");


$delay = (int)input("\n⏱ Nhập delay giữa các like (giây): ");
$limit_per_token = (int)input("🔁 Nhập số lượng FOLLOW mỗi token trước khi đổi: ");

$headers = ["User-Agent: Mozilla/5.0", "X-Requested-With: XMLHttpRequest"];

$login = curl_post('https://tuongtaccheo.com/logintoken.php', ['access_token' => $ttc_token]);
$data = json_decode($login, true);
if ($data['status'] != 'success') die("❌ Login TTC thất bại\n");
echo "\n✅ Đăng nhập TTC thành công: {$data['data']['user']} | Số dư: {$data['data']['sodu']} xu\n";

$token_index = 0;
$like_count = 0;
$stt = 0;
$fail_count = 0;


while (true) {
    if (!isset($fb_tokens[$token_index])) {
        $token_index = 0; // ✅ Lặp lại danh sách token
    }

    $fb_token = $fb_tokens[$token_index];
    $uid_json = file_get_contents("https://graph.facebook.com/me?access_token=$fb_token");
    $uid_data = json_decode($uid_json, true);

    if (!isset($uid_data['id'])) {
        echo "❌ Token không hợp lệ, chuyển token khác...\n";
        $token_index++;
        continue;
    }

    $fb_token = $fb_tokens[$token_index];
    $uid_json = file_get_contents("https://graph.facebook.com/me?access_token=$fb_token");
    $uid_data = json_decode($uid_json, true);

    if (!isset($uid_data['id'])) {
        echo "❌ Token không hợp lệ, chuyển token khác...\n";
        $token_index++;
        continue;
    }
 
      $fb_uid = $uid_data['id'];
    $fb_name = $uid_data['name'];
    // === ĐẶT NICK ===
$datnick = curl_post(
    'https://tuongtaccheo.com/cauhinh/datnick.php',
    "iddat%5B%5D=$fb_uid&loai=fb",
    array_merge($headers, [
        "Content-Type: application/x-www-form-urlencoded; charset=UTF-8"
    ])
);
if (strpos($datnick, '1') !== false) {
    echo "CẤU HÌNH THÀNH CÔNG: $fb_name ID: $fb_uid\n";
} else {
    echo " CẤU HÌNH THẤT BẠI:  $datnick\n";
}
    $getpost = curl_get("https://tuongtaccheo.com/kiemtien/subcheo/getpost.php", $headers);
    $posts = json_decode($getpost, true);

    if (!$posts) {
        echo "⏳ Không có nhiệm vụ, chờ 10s...\n";
        sleep(10);
        continue;
    }

    foreach ($posts as $post) {
        $page_id = basename($post['link']);
        $idpost = $post['idpost'];
        $stt++;

        if (!follow($fb_token, $idpost)) {
            echo "❌ $stt | FOLLOW thất bại | Page: $idpost\n";
            $fail_count++;

            if ($fail_count >= 4) {
                echo "⚠️ FOLLOW thất bại 4 lần liên tiếp. Chuyển token khác...\n";
                $token_index++;
                $like_count = 0;
                $fail_count = 0;
                break;
            }

            continue;
        }

        $fail_count = 0; // reset nếu thành công

        $nhan = curl_post("https://tuongtaccheo.com/kiemtien/subcheo/nhantien.php", "id=$idpost", array_merge($headers, ["Content-Type: application/x-www-form-urlencoded; charset=UTF-8"]));
        $xu = (preg_match('/\d+/', $nhan, $m)) ? $m[0] : "???";
        echo "$stt | " . date("H:i:s") . " | $idpost | FOLLOW | +$xu xu |\n";

        $like_count++;
        if ($like_count >= $limit_per_token) {
            echo "⚠️ Đã đủ $limit_per_token FOLLOW. Chuyển token...\n";
            $token_index++;
            $like_count = 0;
            break;
        }

        sleep($delay);
    }
}

