

<?php
// Gộp lại từ đoạn mã bạn gửi với chỉnh sửa đầy đủ logic:

date_default_timezone_set("Asia/Ho_Chi_Minh");

$cookie_file = __DIR__ . '/cookie.txt';

function input($text) {
    echo $text;
    return trim(fgets(STDIN));
}
function like($fb_token, $page_id) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$page_id.'/likes');
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "authority: m.facebook.com";
    $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
    $head[] = "cache-control: max-age=0";
    $head[] = "upgrade-insecure-requests: 1";
    $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $head[] = "sec-fetch-site: none";
    $head[] = "sec-fetch-mode: navigate";
    $head[] = "sec-fetch-user: ?1";
    $head[] = "sec-fetch-dest: document";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $data = array('access_token' => $fb_token);
    curl_setopt($ch, CURLOPT_POST, count($data));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);

}

function curl_post($url, $data, $headers = []) {
    global $cookie_file;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => is_array($data) ? http_build_query($data) : $data,
        CURLOPT_COOKIEJAR => $cookie_file,
        CURLOPT_COOKIEFILE => $cookie_file,
        CURLOPT_HTTPHEADER => $headers,
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    return $res;
}

function curl_get($url, $headers = []) {
    global $cookie_file;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_COOKIEJAR => $cookie_file,
        CURLOPT_COOKIEFILE => $cookie_file,
        CURLOPT_HTTPHEADER => $headers,
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    return $res;
}

// === NHẬP TOKEN TTC ===
$ttc_token_file = __DIR__ . '/ttc_token.txt';
if (file_exists($ttc_token_file)) {
    $old = trim(file_get_contents($ttc_token_file));
    $use_old = strtolower(input("❓ Dùng lại token TTC cũ? (y/n): "));
    if ($use_old === 'y') {
        $ttc_token = $old;
    } else {
        $ttc_token = input("🔐 Nhập token Tương Tác Chéo: ");
        file_put_contents($ttc_token_file, $ttc_token);
    }
} else {
    $ttc_token = input("🔐 Nhập token Tương Tác Chéo: ");
    file_put_contents($ttc_token_file, $ttc_token);
}
// === NHẬP DANH SÁCH TOKEN FACEBOOK ===
$fb_token_file = __DIR__ . '/fb_tokens.txt';
$fb_tokens = [];

if (file_exists($fb_token_file)) {
    $use_old_fb = strtolower(input("❓ Dùng lại danh sách Facebook token cũ? (y/n): "));
    if ($use_old_fb === 'y') {
        $fb_tokens = array_filter(array_map('trim', file($fb_token_file)));
    }
}

if (empty($fb_tokens)) {
    echo "📥 Nhập nhiều token Facebook, mỗi dòng 1 token. Nhấn Enter dòng trống để kết thúc:\n";
    while (true) {
        $line = trim(fgets(STDIN));
        if ($line === '') break; // nếu dòng trống thì kết thúc
        $fb_tokens[] = $line;
    }
    file_put_contents($fb_token_file, implode("\n", $fb_tokens));
}

if (count($fb_tokens) === 0) die("❌ Không có token Facebook nào!\n");


$delay = (int)input("\n⏱ Nhập delay giữa các like (giây): ");
$limit_per_token = (int)input("🔁 Nhập số lượng like mỗi token trước khi đổi: ");

$headers = ["User-Agent: Mozilla/5.0", "X-Requested-With: XMLHttpRequest"];

$login = curl_post('https://tuongtaccheo.com/logintoken.php', ['access_token' => $ttc_token]);
$data = json_decode($login, true);
if ($data['status'] != 'success') die("❌ Login TTC thất bại\n");
echo "\n✅ Đăng nhập TTC thành công: {$data['data']['user']} | Số dư: {$data['data']['sodu']} xu\n";

$token_index = 0;
$like_count = 0;
$stt = 0;
$fail_count = 0;

while (true) {
    if (!isset($fb_tokens[$token_index])) {
        $ask = strtolower(input("❓ Hết token. Nhập thêm? (y/n): "));
        if ($ask === 'y') {
            echo "📥 Nhập thêm token, mỗi dòng 1 token. Nhập 'done' để kết thúc:\n";
            while (true) {
                $line = trim(fgets(STDIN));
                if (strtolower($line) === 'done') break;
                $fb_tokens[] = $line;
            }
            continue;
        } else {
            echo "🛑 Kết thúc do hết token.\n";
            break;
        }
    }

    $fb_token = $fb_tokens[$token_index];
    $uid_json = file_get_contents("https://graph.facebook.com/me?access_token=$fb_token");
    $uid_data = json_decode($uid_json, true);

    if (!isset($uid_data['id'])) {
        echo "❌ Token không hợp lệ, chuyển token khác...\n";
        $token_index++;
        continue;
    }

    $fb_uid = $uid_data['id'];
    $fb_name = $uid_data['name'];
    // === ĐẶT NICK ===
   // === ĐẶT NICK ===
$datnick = curl_post(
    'https://tuongtaccheo.com/cauhinh/datnick.php',
    "iddat%5B%5D=$fb_uid&loai=fb",
    array_merge($headers, [
        "Content-Type: application/x-www-form-urlencoded; charset=UTF-8"
    ])
);
if (strpos($datnick, '1') !== false) {
    echo "CẤU HÌNH THÀNH CÔNG: $fb_name ID: $fb_uid\n";
    sleep(5);
} else {
    echo " CẤU HÌNH THẤT BẠI:  $datnick\n";
}

 // Gọi API
$getpost = curl_get("https://tuongtaccheo.com/kiemtien/likepostvipre/getpost.php", $headers);
$posts = json_decode($getpost, true);

// Nếu phản hồi là lỗi dạng chuỗi thông báo
if (isset($posts['error'])) {
    $countdown = isset($posts['countdown']) ? $posts['countdown'] : 10;
    echo "⛔ {$posts['error']} | Đợi $countdown giây...\n";
    sleep($countdown);
    continue;
}

// Nếu không phải mảng danh sách nhiệm vụ
if (!is_array($posts)) {
    echo "⏳ Không có nhiệm vụ hoặc phản hồi lỗi không xác định:\n$getpost\n";
    sleep(10);
    continue;
}

// Tiếp tục xử lý bình thường...
foreach ($posts as $index => $post) {
    if (!is_array($post) || !isset($post['idpost']) || !isset($post['idfb'])) {
        echo "⚠️ Lỗi dữ liệu tại nhiệm vụ #$index:\n";
        print_r($post);
        continue;
    }

    $idpost = $post['idpost'];
    $page_id = $post['idfb'];


        $stt++;

        if (!like($fb_token, $page_id)) {
            echo "❌ $stt | Like thất bại | Page: $page_id\n";
            $fail_count++;

            if ($fail_count >= 4) {
                echo "⚠️ Like thất bại 4 lần liên tiếp. Chuyển token khác...\n";
                $token_index++;
                $like_count = 0;
                $fail_count = 0;
                break;
            }

            continue;
        }

        $fail_count = 0; // reset nếu thành công

        $nhan = curl_post("https://tuongtaccheo.com/kiemtien/likepostvipre/nhantien.php", "id=$idpost", array_merge($headers, ["Content-Type: application/x-www-form-urlencoded; charset=UTF-8"]));
        $xu = (preg_match('/\d+/', $nhan, $m)) ? $m[0] : "???";
        echo "$stt | " . date("H:i:s") . " | $page_id | LIKE | +$xu xu |\n";

        $like_count++;
        if ($like_count >= $limit_per_token) {
            echo "⚠️ Đã đủ $limit_per_token like. Chuyển token...\n";
            $token_index++;
            $like_count = 0;
            break;
        }

        sleep($delay);
    }
}

